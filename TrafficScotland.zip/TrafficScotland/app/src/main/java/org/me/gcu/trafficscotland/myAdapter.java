package org.me.gcu.trafficscotland;

//Beth Rocks S1825127

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

public class myAdapter extends ArrayAdapter<TrafficItem> implements Filterable {
    public ArrayList<TrafficItem> ogTrafItems;
    public ArrayList<TrafficItem> trafItems;
    private Filter filter;
    private Context cont;
    private Boolean inc = false;


    private static LayoutInflater inflater = null;

    public myAdapter (Context context, ArrayList<TrafficItem> _items) {
        super(context, 0, _items);
        cont = context;
        this.ogTrafItems = _items;
        this.trafItems = _items;

    }


    @Override
    public TrafficItem getItem(int position) {
        return trafItems.get(position);
    }

    @Override
    public int getCount() {
        return trafItems.size();
    }

    @Override
    public long getItemId(int position) {
        return trafItems.get(position).hashCode();
    }

    @Override
    public View getView(final int position, View convertView, final ViewGroup parent) {
        TrafficItem it = getItem(position);

        ItemHolder holder = new ItemHolder();

        if (convertView == null) {
            Log.d("MyTag", "No Filter");
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.my_list_view, parent, false);
            TextView tvName = (TextView) convertView.findViewById(R.id.tvName);
            TextView tvPeriod = (TextView) convertView.findViewById(R.id.tvPeriod);
            LinearLayout LlClick= (LinearLayout) convertView.findViewById(R.id.LlClick);

            holder.clickable = LlClick  ;
            holder.itemTitleView = tvName;
            holder.itemPeriodView = tvPeriod;

            tvName.setText(it.getTitle());
            tvPeriod.setText(it.getPeriod());


            inc = it.getInc();
            if (inc == false){
                TextView tvDuration= (TextView) convertView.findViewById(R.id.tvDuration);
                tvDuration.setText(Long.toString(it.getDuration())+" hrs");
                tvDuration.setBackgroundColor(Color.parseColor(it.getColour()));
                holder.itemDurationView = tvDuration;
            }
            convertView.setTag(holder);
        }else{
            holder = (ItemHolder) convertView.getTag();
        }

        final TrafficItem t = trafItems.get(position);
        Log.e("MyTag","TRAFFIC ITEM! -"+t);

        TextView tv =  holder.itemTitleView;
        tv.setText(t.getTitle());
        if (inc == false) {
            holder.itemPeriodView.setText(t.getPeriod());
            holder.itemDurationView.setText(Long.toString(t.getDuration()) + " hrs");
            holder.itemDurationView.setBackgroundColor(Color.parseColor(it.getColour()));
        }else {
            holder.itemPeriodView.setText("");
        }
        holder.clickable.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent i = new Intent(cont, ItemActivity.class);

                i.putExtra("title", t.getTitle());
                i.putExtra("desc", t.getDescr());
                i.putExtra("inc", t.getInc());
                i.putExtra("pub", t.getPubDate());
                i.putExtra("geo", t.getGeoRss());

                if(inc == false) {
                    i.putExtra("period", t.getPeriod2());
                    i.putExtra("col", t.getColour());
                }
                cont.startActivity(i);
            }
        });
        return convertView;
    }


    public void resetData() {
        trafItems = ogTrafItems;
    }

    private static class ItemHolder {
        public TextView itemTitleView;
        public TextView itemPeriodView;
        public TextView itemDurationView;
        public LinearLayout clickable;
    }

    @Override
    public Filter getFilter() {

        Log.e("MyTag"," ** FILTER ** ");
        if (filter == null)
            filter = new myFilter();
        Log.d("MyTag"," ** ");
        Log.d("MyTag"," * ");

        return filter;

    }

    private class myFilter extends Filter {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            FilterResults results = new FilterResults();

            if (constraint == null || constraint.length() == 0)
            {
                ArrayList<TrafficItem> ar = new ArrayList<TrafficItem>(ogTrafItems);
                results.values = ar;
                results.count = ar.size();
            }
            else {
                ArrayList<TrafficItem> nItemList = new ArrayList<TrafficItem>();
                for (TrafficItem p : ogTrafItems) {
                    if ((p.getTitle().toUpperCase().contains(constraint.toString().toUpperCase())) | (p.getPeriod().toUpperCase().contains(constraint.toString().toUpperCase()))) {
                        nItemList.add(p);
                    }
                }
                results.values = nItemList;
                results.count = nItemList.size();
            }
            return results;
        }

        @Override
        protected void publishResults(CharSequence constraint,
                                      FilterResults results) {
            if (results.count == 0)
                notifyDataSetInvalidated();
            else {
                trafItems = (ArrayList<TrafficItem>) results.values;
                notifyDataSetChanged();
            }
        }
    }

}


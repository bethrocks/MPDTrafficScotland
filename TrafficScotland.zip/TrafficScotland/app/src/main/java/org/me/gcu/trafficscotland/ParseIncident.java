package org.me.gcu.trafficscotland;
//Beth Rocks S1825127
import android.util.Log;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.StringReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class ParseIncident
{
    private static final String TAG = "ParseIncidents";
    private ArrayList<TrafficItem> applications;

    public ParseIncident() {
        this.applications = new ArrayList<>();
    }

    private Date[] getDates(String[] parts)
    {
        Date newformatStartDate = null;
        Date newformatEndDate = null;

        try{
            String sDate = parts[0].substring(12);
            String eDate = parts[1].substring(10);

            SimpleDateFormat sdf = new SimpleDateFormat("EEE, d MMMMM yyyy - HH:mm", Locale.ENGLISH);
            Date sd = sdf.parse(sDate);
            Date ed = sdf.parse(eDate);

            sdf.applyPattern("dd/MM/yy HH:mm");
            String startDate = sdf.format(sd);
            String endDate = sdf.format(ed);
            newformatStartDate = sdf.parse(startDate);
            newformatEndDate = sdf.parse(endDate);

        } catch (ParseException e){
            e.printStackTrace();
        }
        return new Date[]{newformatStartDate, newformatEndDate};
    };

    private long getDur (Date[] dates){
        Date startDate = dates[0];
        Date endDate = dates[1];

        long diffInMillies = Math.abs(endDate.getTime() - startDate.getTime());
        long diff = TimeUnit.HOURS.convert(diffInMillies, TimeUnit.MILLISECONDS);

        return diff;
    }

    public ArrayList<TrafficItem> getApplications() {
        return applications;
    }

    public boolean parse(String xmlData) {
        boolean status = true;
        TrafficItem currentTrafficItem = null;
        boolean inEntry = false;
        String textValue = "";
        Log.d(TAG, "parse: xmldata: " + xmlData);

        try {
            Log.d(TAG, "parse: Try");
            XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
            factory.setNamespaceAware(true);
            XmlPullParser xpp = factory.newPullParser();
            xpp.setInput(new StringReader(xmlData));
            int eventType = xpp.getEventType();

            while(eventType != XmlPullParser.END_DOCUMENT) {
                String tagName = xpp.getName();
                switch (eventType) {
                    case XmlPullParser.START_TAG:
                        if("item".equalsIgnoreCase(tagName)) {
                            inEntry = true;
                            currentTrafficItem = new TrafficItem();
                        }
                        break;

                    case XmlPullParser.TEXT:
                        textValue = xpp.getText();
                        break;

                    case XmlPullParser.END_TAG:
                        if(inEntry) {
                            if("item".equalsIgnoreCase(tagName)) {
                                applications.add(currentTrafficItem);
                                inEntry = false;
                            } else if("title".equalsIgnoreCase(tagName)) {
                                currentTrafficItem.setTitle(textValue);
                            }else if("description".equalsIgnoreCase(tagName)) {
                                if (textValue.contains("Start Date:")) {
                                    String[] parts = textValue.split("<br />");
                                    Date dates[] = getDates(parts);
                                    long duration = getDur(dates);

                                    String period = dates[0].toString().substring(0, 10) + " - " + dates[1].toString().substring(0, 10) ;
                                    String period2 = dates[0].toString().substring(0, 23) + " - " + dates[1].toString().substring(0, 23) ;

                                    currentTrafficItem.setDesc(parts[2]);
                                    currentTrafficItem.setStartDate(dates[0]);
                                    currentTrafficItem.setEndDate(dates[1]);
                                    currentTrafficItem.setPeriod(period);
                                    currentTrafficItem.setPeriod2(period2);
                                    currentTrafficItem.setDuration(duration);
                                    currentTrafficItem.setInc(false);

                                } else {currentTrafficItem.setInc(true); currentTrafficItem.setDesc(textValue);}
                            }else if("link".equalsIgnoreCase(tagName)) {
                                currentTrafficItem.setLink(textValue);
                            }else if("point".equalsIgnoreCase(tagName)) {
                                Log.d("MyTag", "GEO TAG: "+textValue);
                                currentTrafficItem.setGeoRss(textValue);
                            }
                        }
                        break;
                    default:
                }
                eventType = xpp.next();

            }
            for (TrafficItem app: applications) {

            }

        } catch(Exception e) {
            status = false;
            e.printStackTrace();
        }
        return status;
    }
}
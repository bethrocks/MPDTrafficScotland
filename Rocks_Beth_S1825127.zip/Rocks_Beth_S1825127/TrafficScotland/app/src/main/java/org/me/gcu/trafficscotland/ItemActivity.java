package org.me.gcu.trafficscotland;
//Beth Rocks S1825127
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


public class ItemActivity extends AppCompatActivity implements View.OnClickListener
{
    String geo;
    TextView t_title;
    TextView t_period;
    TextView t_description;
    TextView t_desc2;
    TextView t_desc3;
    TextView t_duration;
    TextView t_geo;
    String type;

    Button mapButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item);

        Intent intent = getIntent();
        t_title = findViewById(R.id.itemTitle);
        t_description = findViewById(R.id.itemD1);
        t_geo = findViewById(R.id.itemGeo);
        t_desc3= findViewById(R.id.itemD3);
        t_desc2 = findViewById(R.id.itemD2);

        t_duration = findViewById(R.id.itemDuration);
        t_period = findViewById(R.id.itemPeriod);
        mapButton = (Button) findViewById(R.id.mapButton);
        mapButton.setOnClickListener(this);



        String title = intent.getExtras().getString("title");
        String period = intent.getExtras().getString("period");
        String dur = intent.getExtras().getString("dur");
        String d = intent.getExtras().getString("desc");
        Boolean incident = intent.getExtras().getBoolean("inc");
        String description = "";
        String desc2 = "";
        String desc3 = "";
        Log.e("MyTag","title "+title);
        Log.e("MyTag","desc "+d);
        Log.e("MyTag","desc "+d);

        if (incident == true){type = "i";}
        else{
            if(d.contains("Works:")){
                type = "works";
            }if(d.contains("TYPE :")){
                type = "type";
            }if(d.contains("Delay Information")){
                type = "delay";
            }
        }

        String desc[];
        switch (type) {
            case "works":
                desc = d.split("Works:|Traffic Management:|Diversion Information:");
                Log.e("MyTag","desc[0] -> "+desc[1]);
                description = desc[1];
                if (desc.length > 2){
                    Log.e("MyTag","desc[1] -> "+desc[2]);
                    desc2 = desc[2];}
                if (desc.length > 3){
                    Log.e("MyTag","desc[2] -> "+desc[3]);
                    desc3 = desc[3];}
                break;

            case "type":
                desc = d.split("TYPE :|Lane Closures :|Location :");
                description = desc[1];
                if (desc.length > 2){
                    Log.e("MyTag","desc[2] -> "+desc[2]);
                    desc2 = desc[2]; }
                if (desc.length > 3){
                    Log.e("MyTag","desc[3] -> "+desc[3]);
                    desc3 = desc[3]; }
                break;
            case "delay":
                desc = d.split("Delay Information");
                description = desc[1];
                break;
            case "i":
                description = d;
                break;
        }
        geo = intent.getExtras().getString("geo");

        Log.e("MyTag","intent: "+intent);
        Log.e("MyTag"," "+title);
        Log.e("MyTag","--");
        t_title.setText(title);
        t_description.setText(description);
        t_geo.setText(geo);

        if (incident == false) {
            String col = intent.getExtras().getString("col");

            t_desc2.setText(desc2);
            t_desc3.setText(desc3);
            t_period.setText(period);
            t_duration.setText(dur);
            t_duration.setBackgroundColor(Color.parseColor(col));
        }

    }

    public void onClick(View view) {
        Intent i = new Intent(ItemActivity.this, MapsActivity.class);
        i.putExtra("geo", geo);

        ItemActivity.this.startActivity(i);
    }
}
